# 八股文

配方： ℞ **essay**

[Rime](https://rime.im) 預設詞彙表及語言模型

## 安裝

[東風破](https://github.com/rime/plum) 安裝口令： `bash rime-install essay`

授權條款：見 [LICENSE](LICENSE)
