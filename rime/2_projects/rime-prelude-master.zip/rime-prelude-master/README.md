# rime-prelude

配方： ℞ **prelude**

[Rime](https://rime.im) 輸入法基礎配置

提供 `default.yaml` 及常用 Rime 組件的默認配置

## 安裝

[東風破](https://github.com/rime/plum) 安裝口令： `bash rime-install prelude`

授權條款：見 [LICENSE](LICENSE)
