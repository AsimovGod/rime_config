# 朙月拼音

配方： ℞ **luna-pinyin**

[Rime](https://rime.im) 拼音輸入方案

致敬 [昇陽拼音](https://github.com/sunpinyin/sunpinyin)

## 用法

拼音字母 ü 用 `v` 鍵輸入。

本方案不支持輸入聲調。如有需要，請用 [地球拼音](https://github.com/rime/rime-terra-pinyin)。

## 安裝

[東風破](https://github.com/rime/plum) 安裝口令： `bash rime-install luna-pinyin`

授權條款：見 [LICENSE](LICENSE)
